import React, { useState, useEffect } from 'react';
import { 
  Send, 
  Mic, 
  CheckCheck, 
  Phone, 
  Video, 
  MoreVertical, 
  Play, 
  Pause,
  ExternalLink,
  Landmark,
  Flag
} from 'lucide-react';
import { bhashini } from '../services/bhashiniService';

export default function WhatsAppBot({ profile, onApplyScheme, currentLang = 'en' }) {
  const t = (k) => bhashini.t(k, currentLang);
  
  const getInitialWelcome = (lang) => {
    const name = profile?.name || 'Citizen';
    const state = profile?.state || 'India';
    const brand = bhashini.t('brandTitle', lang) || 'SchemeSetu AI';

    if (lang === 'hi') {
      return `🇮🇳 नमस्ते ${name} जी (${state})! मैं आपका ${brand} सरकारी योजना मित्र हूँ। आप केंद्रीय योजनाओं (PMEGP, मुद्रा, स्टैंड-अप इंडिया) या अपने राज्य की योजनाओं (जैसे कर्नाटक, तेलंगाना, महाराष्ट्र, उप्र, आदि) के बारे में कुछ भी पूछ सकते हैं।`;
    }
    if (lang === 'kn') {
      return `🇮🇳 ನಮಸ್ಕಾರ ${name} ಅವರೇ (${state})! ನಾನು ನಿಮ್ಮ ${brand} ಸರ್ಕಾರಿ ಯೋಜನೆ ಮಾರ್ಗದರ್ಶಿ. ನೀವು ಕೇಂದ್ರ ಯೋಜನೆಗಳು (PMEGP, ಮುದ್ರಾ) ಅಥವಾ ಕರ್ನಾಟಕ ಸರ್ಕಾರದ ಯೋಜನೆಗಳ (ಗೃಹ ಲಕ್ಷ್ಮಿ, ಯುವ ನಿಧಿ, ಸಿಎಂಇಜಿಪಿ) ಬಗ್ಗೆ ಕೇಳಬಹುದು.`;
    }
    if (lang === 'te') {
      return `🇮🇳 నమస్కారం ${name} గారు (${state})! నేను మీ ${brand} ప్రభుత్వ పథకాల సలహాదారుని. మీరు కేంద్ర మరియు రాష్ట్ర ప్రభుత్వ సంక్షేమ పథకాల గురించి నన్ను అడగవచ్చు.`;
    }
    if (lang === 'ta') {
      return `🇮🇳 வணக்கம் ${name} (${state})! நான் உங்கள் ${brand} அரசு திட்ட ஆலோசகர். மத்திய மற்றும் மாநில அரசு திட்டங்கள் குறித்து நீங்கள் எதையும் கேட்கலாம்.`;
    }
    if (lang === 'mr') {
      return `🇮🇳 नमस्कार ${name} (${state})! मी आपला ${brand} शासकीय योजना मित्र आहे. आपण केंद्र व राज्य शासनाच्या योजनांबद्दल विचारू शकता.`;
    }
    if (lang === 'gu') {
      return `🇮🇳 નમસ્તે ${name} (${state})! હું તમારો ${brand} સરકારી યોજના મિત્ર છું. તમે કેન્દ્રીય અને રાજ્ય યોજનાઓ વિશે પૂછી શકો છો.`;
    }
    if (lang === 'bn') {
      return `🇮🇳 নমস্কার ${name} (${state})! আমি আপনার ${brand} সরকারি প্রকল্প সহায়ক। আপনি কেন্দ্রীয় এবং রাজ্য সরকারি প্রকল্প সম্পর্কে জিজ্ঞাসা করতে পারেন।`;
    }
    if (lang === 'pa') {
      return `🇮🇳 ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ ${name} (${state})! ਮੈਂ ਤੁਹਾਡਾ ${brand} ਸਰਕਾਰੀ ਸਕੀਮ ਮਿੱਤਰ ਹਾਂ। ਤੁਸੀਂ ਕੇਂਦਰੀ ਅਤੇ ਰਾਜ ਸਰਕਾਰ ਦੀਆਂ ਸਕੀਮਾਂ ਬਾਰੇ ਪੁੱਛ ਸਕਦੇ ਹੋ।`;
    }
    if (lang === 'ml') {
      return `🇮🇳 നമസ്കാരം ${name} (${state})! ഞാൻ നിങ്ങളുടെ ${brand} സർക്കാർ പദ്ധതി ഉപദേശകനാണ്. കേന്ദ്ര-സംസ്ഥാന പദ്ധതികളെക്കുറിച്ച് നിങ്ങൾക്ക് ചോദിക്കാം.`;
    }
    return `🇮🇳 Welcome ${name} (${state})! I am your ${brand} Government Welfare Counselor. You can ask me anything about Central Schemes (PMEGP, Mudra, Stand-Up India, PM Vishwakarma) or State Schemes (Karnataka, Telangana, Maharashtra, UP, etc.).`;
  };

  const getProfileSummary = (lang) => {
    const occ = profile?.occupation || 'Entrepreneur';
    const cat = profile?.category || 'OBC';
    const state = profile?.state || 'National';
    const inc = Number(profile?.income || 120000).toLocaleString('en-IN');

    if (lang === 'hi') {
      return `आपकी प्रोफाइल (${occ}, ${cat}, निवास: ${state}, ₹${inc}/वर्ष) के आधार पर हमने केंद्रीय और राज्य सरकार दोनों की योजनाएं जांची हैं!`;
    }
    if (lang === 'kn') {
      return `ನಿಮ್ಮ ಪ್ರೊಫೈಲ್ (${occ}, ${cat}, ರಾಜ್ಯ: ${state}, ₹${inc}/ವರ್ಷ) ಆಧರಿಸಿ ನಾವು ಕೇಂದ್ರ ಮತ್ತು ರಾಜ್ಯ ಸರ್ಕಾರಗಳ ಯೋಜನೆಗಳನ್ನು ವಿಶ್ಲೇಷಿಸಿದ್ದೇವೆ!`;
    }
    if (lang === 'te') {
      return `మీ ప్రొఫైల్ (${occ}, ${cat}, రాష్ట్రం: ${state}, ₹${inc}/సంవత్సరం) ఆధారంగా మేము కేంద్ర మరియు రాష్ట్ర ప్రభుత్వ పథకాలను పరిశీలించాము!`;
    }
    if (lang === 'ta') {
      return `உங்கள் சுயவிவரம் (${occ}, ${cat}, மாநிலம்: ${state}, ₹${inc}/ஆண்டு) அடிப்படையில் மத்திய மற்றும் மாநில அரசு திட்டங்களை நாங்கள் ஆராய்ந்துள்ளோம்!`;
    }
    return `Based on your verified profile (${occ}, ${cat}, State: ${state}, ₹${inc}/yr), we have analyzed both Central and State Government welfare schemes!`;
  };

  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  useEffect(() => {
    setMessages([
      {
        id: 1,
        sender: 'bot',
        text: getInitialWelcome(currentLang),
        time: '10:45 AM',
        audio: true
      },
      {
        id: 2,
        sender: 'bot',
        text: getProfileSummary(currentLang),
        time: '10:46 AM'
      }
    ]);
  }, [currentLang, profile?.state]);

  const quickPrompts = currentLang === 'en' ? [
    '🏛️ What are the top Central Government schemes?',
    '🚩 Explain Karnataka Gruha Lakshmi & Yuva Nidhi schemes',
    '🚩 What is Telangana Dalit Bandhu (₹10 Lakh grant)?',
    '🚩 What is Maharashtra Majhi Ladki Bahin Yojana?',
    'How to apply for PMEGP 35% Capital Subsidy?'
  ] : currentLang === 'kn' ? [
    '🏛️ ಕೇಂದ್ರ ಸರ್ಕಾರದ ಪ್ರಮುಖ ಯೋಜನೆಗಳು ಯಾವುವು?',
    '🚩 ಕರ್ನಾಟಕದ ಗೃಹ ಲಕ್ಷ್ಮಿ ಮತ್ತು ಯುವ ನಿಧಿ ಯೋಜನೆಗಳ ವಿವರ',
    '🚩 ಕರ್ನಾಟಕ ಸಿಎಂಇಜಿಪಿ (CMEGP) 35% ಸಬ್ಸಿಡಿ ಯೋಜನೆ',
    '🚩 ಗಂಗಾ ಕಲ್ಯಾಣ ಉಚಿತ ಕೊಳವೆಬಾವಿ ಯೋಜನೆ',
    'PMEGP 35% ಸಬ್ಸಿಡಿಗೆ ಅರ್ಜಿ ಸಲ್ಲಿಸುವುದು ಹೇಗೆ?'
  ] : currentLang === 'te' ? [
    '🏛️ కేంద్ర ప్రభుత్వ ముఖ్య పథకాలు ఏమిటి?',
    '🚩 తెలంగాణ దళిత బంధు (₹10 లక్షలు) పథకం ఏమిటి?',
    '🚩 రైతు భరోసా పథకం వివరాలు',
    'PMEGP 35% సబ్సిడీకి ఎలా దరఖాస్తు చేయాలి?'
  ] : [
    '🏛️ केंद्रीय सरकार की मुख्य योजनाएं क्या हैं?',
    '🚩 कर्नाटक की गृह लक्ष्मी व युवा निधि योजनाएं बताएं',
    '🚩 तेलंगाना की दलित बंधु (₹10 लाख) योजना क्या है?',
    '🚩 महाराष्ट्र की लाडकी बहिन (₹1500/माह) योजना क्या है?',
    'PMEGP 35% सब्सिडी के लिए कैसे आवेदन करें?'
  ];

  const handleSend = (textToSend = inputText) => {
    if (!textToSend.trim()) return;

    const userMsg = {
      id: Date.now(),
      sender: 'user',
      text: textToSend,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');

    setTimeout(() => {
      let reply = ``;
      const q = textToSend.toLowerCase();

      if (q.includes('कर्नाटक') || q.includes('karnataka') || q.includes('gruha') || q.includes('ಗೃಹ') || q.includes('yuva')) {
        reply = currentLang === 'en'
          ? `🚩 **Karnataka State Government Welfare Schemes**:\n1. **Gruha Lakshmi Scheme**: ₹2,000/month (₹24,000/yr) direct DBT cash transfer to the female head of the family.\n2. **Yuva Nidhi Scheme**: ₹3,000/month for unemployed graduates, ₹1,500/month for diploma holders for up to 2 years.\n3. **Ganga Kalyana Scheme**: Free individual irrigation borewells with pumps up to ₹4.5 Lakhs.\n👉 Official Portal: sevasindhu.karnataka.gov.in / cmegp.kar.nic.in`
          : `🚩 **कर्नाटक राज्य सरकार योजनाएं (Govt of Karnataka)**:\n1. **गृह लक्ष्मी योजना (Gruha Lakshmi)**: परिवार की महिला मुखिया को ₹2,000/माह (₹24,000/वर्ष) सीधा DBT नकद लाभ।\n2. **युवा निधि योजना (Yuva Nidhi)**: बेरोजगार स्नातकों को ₹3,000/माह एवं डिप्लोमा धारकों को ₹1,500/माह।\n3. **गंगा कल्याण योजना (Ganga Kalyana)**: SC/ST/OBC किसानों के लिए ₹4.5 लाख तक 100% सब्सिडी से बोरवेल ও پمپ सेट।\n👉 Seva Sindhu: sevasindhu.karnataka.gov.in`;
      } else if (q.includes('तेलंगाना') || q.includes('telangana') || q.includes('dalit') || q.includes('దళిత') || q.includes('rythu')) {
        reply = currentLang === 'en'
          ? `🚩 **Telangana State Government Welfare Schemes**:\n1. **Dalit Bandhu Scheme**: ₹10,00,000 100% direct financial grant per SC family for self-employment (zero loan, zero repayment)!\n2. **Rythu Bharosa**: ₹15,000/acre/year input support for farmers.\n👉 Official Portal: telangana.gov.in`
          : `🚩 **तेलंगाना राज्य सरकार योजनाएं (Govt of Telangana)**:\n1. **दलित बंधु योजना (Dalit Bandhu)**: प्रति SC परिवार ₹10,00,000 का 100% सीधा सरकारी अनुदान (बिना किसी बैंक ऋण या पुनर्भुगतान के)!\n2. **रैतु भरोसा (Rythu Bharosa)**: किसानों को फसल निवेश हेतु ₹15,000/एकड़/वर्ष (₹7,500 प्रति सीजन)।\n👉 telangana.gov.in`;
      } else if (q.includes('महाराष्ट्र') || q.includes('maharashtra') || q.includes('ladki') || q.includes('लाडकी') || q.includes('shetkari')) {
        reply = currentLang === 'en'
          ? `🚩 **Maharashtra State Government Schemes**:\n1. **Mukhyamantri Majhi Ladki Bahin Yojana**: ₹1,500/month (₹18,000/year) direct financial assistance for eligible women aged 21–65.\n2. **Namo Shetkari Mahasanman Nidhi**: ₹6,000/year additional income support for farmers.\n👉 Official Portal: mahadbt.maharashtra.gov.in`
          : `🚩 **महाराष्ट्र राज्य सरकार योजनाएं (Govt of Maharashtra)**:\n1. **मुख्यमंत्री माझी लाडकी बहीण योजना**: 21-65 वर्ष की महिलाओं को ₹1,500/माह (₹18,000/वर्ष) सीधा नकद लाभ।\n2. **नमो शेतकरी महासन्मान निधी**: किसानों को ₹6,000/वर्ष अतिरिक्त अनुदान (PM-KISAN के साथ कुल ₹12,000/वर्ष)।\n👉 mahadbt.maharashtra.gov.in`;
      } else if (q.includes('उत्तर प्रदेश') || q.includes('up') || q.includes('odop') || q.includes('kanya')) {
        reply = currentLang === 'en'
          ? `🚩 **Uttar Pradesh State Government Schemes**:\n1. **UP ODOP Margin Money Scheme**: Up to ₹20 Lakhs project subsidy (25%) for traditional crafts and micro enterprises.\n2. **Mukhyamantri Kanya Sumangala Yojana**: ₹25,000 conditional cash assistance from birth to graduation.\n👉 Official Portal: mksy.up.gov.in`
          : `🚩 **उत्तर प्रदेश राज्य सरकार योजनाएं (Govt of Uttar Pradesh)**:\n1. **UP ODOP मार्जिन मनी योजना**: शिल्पकारों ও उद्यमियों को ₹20 लाख तक की पूंजीगत सब्सिडी (25% तक)।\n2. **मुख्यमंत्री कन्या सुमंगला योजना**: बेटियों के जन्म से स्नातक तक 6 चरणों में ₹25,000 की नकद सहायता।\n👉 mksy.up.gov.in`;
      } else if (q.includes('केंद्रीय') || q.includes('central') || q.includes('केंद्र')) {
        reply = currentLang === 'en'
          ? `🏛️ **Flagship Central Government Schemes (Government of India)**:\n1. **PMEGP**: Up to 35% margin money government subsidy (up to ₹17.5 Lakhs) for new manufacturing & service micro-units.\n2. **Stand-Up India**: ₹10 Lakhs to ₹1 Crore bank loan for SC/ST and Women Entrepreneurs.\n3. **PM Mudra Yojana**: Collateral-free business loans from ₹50,000 to ₹20 Lakhs.\n4. **PM Vishwakarma**: ₹15,000 modern toolkit incentive + ₹3 Lakhs subsidized 5% interest loans for 18 traditional artisan trades.\n5. **PM-KISAN**: ₹6,000/year direct DBT assistance to landholding farmers.`
          : `🏛️ **प्रमुख केंद्रीय सरकार योजनाएं (Government of India)**:\n1. **PMEGP**: नए विनिर्माण व सेवा उद्यमों के लिए 35% तक (₹17.5 लाख) मार्जिन मनी सब्सिडी।\n2. **स्टैंड-अप इंडिया**: महिला ও SC/ST उद्यमियों के लिए ₹10 लाख से ₹1 करोड़ बैंक ऋण।\n3. **पीएम मुद्रा योजना**: बिना गारंटी ₹50,000 से ₹20 लाख का व्यावसायिक ऋण।\n4. **पीएम विश्वकर्मा**: 18 पारंपरिक शिल्पों के लिए ₹15,000 टूलकिट वाउचर व ₹3 लाख का सस्ता ऋण।\n5. **पीएम-किसान**: सभी किसानों को ₹6,000/वर्ष सीधा DBT।`;
      } else if (q.includes('pmegp') || q.includes('subsidy') || q.includes('सब्सिडी')) {
        reply = currentLang === 'en'
          ? `🏛️ **PMEGP 35% Capital Subsidy Scheme**: Project financing up to ₹50 Lakhs for manufacturing and ₹20 Lakhs for services. General category gets 15–25% subsidy; Women/SC/ST/OBC/Special categories get 25–35% government capital subsidy. Apply online directly at kviconline.gov.in.`
          : `🏛️ **PMEGP 35% सब्सिडी योजना**: विनिर्माण के लिए ₹50 लाख और सेवा के लिए ₹20 लाख तक का प्रोजेक्ट। सामान्य वर्ग को 15-25% और महिला/SC/ST/OBC को 25-35% सरकारी अनुदान। kviconline.gov.in पर ऑनलाइन आवेदन करें।`;
      } else {
        reply = currentLang === 'en'
          ? `Hello! On ${bhashini.t('brandTitle', currentLang)}, 16 Central schemes and 98 State welfare schemes (Karnataka, Telangana, Maharashtra, UP, Tamil Nadu, Gujarat, Punjab, Kerala, West Bengal, Bihar, Odisha, etc.) are indexed and available. You can ask for information by scheme name or state.`
          : currentLang === 'kn'
          ? `ನಮಸ್ಕಾರ! ${bhashini.t('brandTitle', currentLang)} ನಲ್ಲಿ 16 ಕೇಂದ್ರ ಮತ್ತು 98 ರಾಜ್ಯ ಮಟ್ಟದ ಯೋಜನೆಗಳು (ಕರ್ನಾಟಕ, ತೆಲಂಗಾಣ, ಮಹಾರಾಷ್ಟ್ರ, ಇತ್ಯಾದಿ) ಲಭ್ಯವಿವೆ.`
          : currentLang === 'te'
          ? `నమస్కారం! ${bhashini.t('brandTitle', currentLang)} లో 16 కేంద్ర మరియు 98 రాష్ట్ర ప్రభుత్వ పథకాలు అందుబాటులో ఉన్నాయి.`
          : `नमस्ते! ${bhashini.t('brandTitle', currentLang)} पर 16 केंद्रीय योजनाएं और 98 राज्य स्तरीय योजनाएं (कर्नाटक, तेलंगाना, महाराष्ट्र, उप्र, तमिलनाडु, गुजरात, पंजाब, केरल, प. बंगाल) उपलब्ध हैं। आप किसी भी राज्य अथवा योजना के नाम से जानकारी ले सकते हैं।`;
      }

      const botMsg = {
        id: Date.now() + 1,
        sender: 'bot',
        text: reply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, botMsg]);
    }, 400);
  };

  const handleToggleAudio = (text) => {
    if (isPlayingAudio) {
      bhashini.stopSpeaking();
      setIsPlayingAudio(false);
    } else {
      setIsPlayingAudio(true);
      bhashini.speak(text, currentLang);
    }
  };

  return (
    <div className="max-w-3xl mx-auto glass-panel rounded-3xl border border-slate-800 overflow-hidden shadow-2xl animate-fadeIn">
      
      {/* WhatsApp Header Bar */}
      <div className="p-4 bg-emerald-900/60 border-b border-emerald-800/80 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-emerald-500 text-slate-950 font-black flex items-center justify-center text-base shadow-md">
              🏛️
            </div>
            <div className="w-3 h-3 rounded-full bg-emerald-400 border-2 border-slate-950 absolute bottom-0 right-0"></div>
          </div>

          <div>
            <div className="text-sm font-bold text-white flex items-center gap-1.5">
              <span>{t('brandTitle')} Counselor</span>
              <span className="px-1.5 py-0.2 rounded text-[10px] bg-emerald-500/20 text-emerald-300 font-mono">Verified Bot</span>
            </div>
            <div className="text-[11px] text-emerald-300">
              Active • Central & State Schemes Advisory
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 text-emerald-200">
          <Phone className="w-4 h-4 cursor-pointer hover:text-white" />
          <Video className="w-4 h-4 cursor-pointer hover:text-white" />
          <MoreVertical className="w-4 h-4 cursor-pointer hover:text-white" />
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="p-4 md:p-6 space-y-4 min-h-[420px] max-h-[500px] overflow-y-auto bg-slate-950/80">
        {messages.map((m) => {
          const isBot = m.sender === 'bot';
          return (
            <div
              key={m.id}
              className={`flex ${isBot ? 'justify-start' : 'justify-end'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl p-3.5 space-y-2 text-xs md:text-sm shadow-md ${
                  isBot
                    ? 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none'
                    : 'bg-emerald-700 text-white rounded-tr-none font-medium'
                }`}
              >
                {/* Audio pill if available */}
                {m.audio && (
                  <div className="flex items-center gap-2 p-2 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs">
                    <button
                      onClick={() => handleToggleAudio(m.text)}
                      className="p-2 rounded-full bg-emerald-500 text-slate-950 hover:bg-emerald-400"
                    >
                      {isPlayingAudio ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    </button>
                    <span className="text-[11px] text-slate-300 font-semibold">
                      {t('listenAudio')} (Bhashini Voice)
                    </span>
                  </div>
                )}

                <div className="whitespace-pre-line leading-relaxed">
                  {m.text}
                </div>

                <div className="flex items-center justify-end gap-1 text-[10px] text-slate-400 pt-1">
                  <span>{m.time}</span>
                  {!isBot && <CheckCheck className="w-3.5 h-3.5 text-emerald-300" />}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Questions Chips */}
      <div className="px-4 py-2.5 bg-slate-900/90 border-t border-slate-800/80 flex items-center gap-2 overflow-x-auto">
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider whitespace-nowrap">
          Quick Queries:
        </span>
        {quickPrompts.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(prompt)}
            className="px-3 py-1 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-emerald-600/30 hover:border-emerald-500 text-slate-200 border border-slate-700 whitespace-nowrap transition-all"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Message Bar */}
      <div className="p-3.5 bg-slate-900 border-t border-slate-800 flex items-center gap-2">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Type in English, Hindi, Telugu, Tamil, Kannada or your language..."
          className="flex-1 px-4 py-2.5 rounded-2xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-xs md:text-sm focus:outline-none focus:border-emerald-500"
        />

        <button
          onClick={() => handleSend()}
          className="p-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold transition-all shadow-md shadow-emerald-500/20"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
}
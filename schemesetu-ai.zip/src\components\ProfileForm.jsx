import React, { useState, useEffect } from 'react';
import { 
  Mic, 
  MicOff, 
  Sparkles, 
  User, 
  Coins, 
  Volume2
} from 'lucide-react';
import { bhashini, SUPPORTED_LANGUAGES } from '../services/bhashiniService';

export const INDIAN_STATES = [
  'National / All India',
  'Andhra Pradesh',
  'Assam',
  'Bihar',
  'Chhattisgarh',
  'Delhi',
  'Gujarat',
  'Haryana',
  'Karnataka',
  'Kerala',
  'Madhya Pradesh',
  'Maharashtra',
  'Odisha',
  'Punjab',
  'Rajasthan',
  'Tamil Nadu',
  'Telangana',
  'Uttar Pradesh',
  'West Bengal'
];

export default function ProfileForm({ profile, setProfile, onRunDiscovery, isAnalyzing, currentLang = 'hi' }) {
  const t = (k) => bhashini.t(k, currentLang);
  const [isListening, setIsListening] = useState(false);
  const [speechTranscript, setSpeechTranscript] = useState('');
  const [voiceLang, setVoiceLang] = useState(currentLang || 'hi');
  const [recognition, setRecognition] = useState(null);

  useEffect(() => {
    setVoiceLang(currentLang);
  }, [currentLang]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recog = new SpeechRecognition();
        recog.continuous = false;
        recog.interimResults = true;
        
        const localeMap = {
          hi: 'hi-IN',
          te: 'te-IN',
          ta: 'ta-IN',
          mr: 'mr-IN',
          bn: 'bn-IN',
          gu: 'gu-IN',
          kn: 'kn-IN',
          pa: 'pa-IN',
          ml: 'ml-IN',
          en: 'en-IN'
        };
        recog.lang = localeMap[voiceLang] || 'hi-IN';

        recog.onresult = (event) => {
          const transcript = Array.from(event.results)
            .map(res => res[0].transcript)
            .join('');
          setSpeechTranscript(transcript);

          const extracted = bhashini.parseVoiceSpeech(transcript);
          if (Object.keys(extracted).length > 0) {
            setProfile(prev => ({ ...prev, ...extracted }));
          }
        };

        recog.onend = () => {
          setIsListening(false);
        };

        setRecognition(recog);
      }
    }
  }, [voiceLang]);

  const toggleVoiceRecording = () => {
    if (!recognition) {
      // Simulate Voice Transcription with authentic regional language sentence
      setIsListening(true);
      setSpeechTranscript(t('listening'));

      const sampleVoiceByLang = {
        hi: "मेरा नाम सुमित्रा देवी है, उम्र 35 वर्ष, वार्षिक आय 1.2 लाख रुपये, मैं महिला उद्यमी हूं और उत्तर प्रदेश से हूं",
        kn: "ನನ್ನ ಹೆಸರು ಸುಮಿತ್ರಾ, ವಯಸ್ಸು 35 ವರ್ಷ, ವಾರ್ಷಿಕ ಆದಾಯ 1.2 ಲಕ್ಷ, ನಾನು ಮಹಿಳಾ ಉದ್ಯಮಿ",
        ml: "എന്റെ പേര് സുമിത്ര, പ്രായം 35 വയസ്സ്, വാർഷിക വരുമാനം 1.2 ലക്ഷം, വനിതാ സംരംഭകയാണ്",
        gu: "મારું નામ સુમિત્રા દેવી છે, ઉંમર 35 વર્ષ, વાર્ષિક આવક 1.2 લાખ, હું મહિલા ઉદ્યોગસાહસિક છું",
        pa: "ਮੇਰਾ ਨਾਮ ਸੁਮਿਤਰਾ ਦੇਵੀ ਹੈ, ਉਮਰ 35 ਸਾਲ, ਸਾਲਾਨਾ ਆਮਦਨ 1.2 ਲੱਖ, ਮੈਂ ਮਹਿਲਾ ਉੱਦਮੀ ਹਾਂ",
        te: "నా పేరు సుమిత్ర, వయస్సు 35 సంవత్సరాలు, వార్షిక ఆదాయం 1.2 లక్షలు, నేను మహిళా వ్యవస్థాపకురాలిని",
        ta: "என் பெயர் சுமித்ரா, வயது 35, ஆண்டு வருமானம் 1.2 லட்சம், நான் பெண் தொழில்முனைவோர்",
        mr: "माझे नाव सुमित्रा देवी आहे, वय 35 वर्षे, वार्षिक उत्पन्न 1.2 लाख, मी महिला उद्योजक आहे",
        bn: "আমার নাম সুমিত্রা দেবী, বয়স ৩৫ বছর, বার্ষিক আয় ১.২ লাখ, আমি মহিলা উদ্যোক্তা",
        en: "My name is Sumitra Devi, age 35, annual income 1.2 Lakhs, I am a women entrepreneur from UP"
      };

      const sampleSentence = sampleVoiceByLang[currentLang] || sampleVoiceByLang['hi'];
      
      setTimeout(() => {
        setSpeechTranscript(sampleSentence);
        const extracted = bhashini.parseVoiceSpeech(sampleSentence);
        setProfile(prev => ({
          ...prev,
          name: 'Sumitra Devi',
          age: 35,
          income: 120000,
          gender: 'Female',
          occupation: 'Women Entrepreneur',
          state: 'Uttar Pradesh',
          category: 'OBC',
          ...extracted
        }));
        setIsListening(false);
      }, 1500);
      return;
    }

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      setSpeechTranscript('');
      recognition.start();
      setIsListening(true);
    }
  };

  const handleChange = (field, value) => {
    setProfile(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onRunDiscovery(profile);
  };

  return (
    <div className="glass-panel p-6 md:p-8 rounded-3xl border border-slate-700/80 shadow-2xl space-y-6">
      
      {/* Header & Voice Studio */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-white flex items-center gap-2">
            <User className="w-6 h-6 text-amber-400" />
            {t('profileStudioTitle')}
          </h2>
          <p className="text-xs md:text-sm text-slate-400 pt-1">
            {t('profileStudioSub')}
          </p>
        </div>

        {/* Bhashini Voice Recording Pill */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={toggleVoiceRecording}
            className={`px-4 py-2.5 rounded-2xl font-bold text-xs flex items-center gap-2 transition-all shadow-lg ${
              isListening
                ? 'bg-red-500 text-white animate-pulse shadow-red-500/30'
                : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/20'
            }`}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            <span>{isListening ? t('listening') : t('speakProfile')}</span>
          </button>
        </div>
      </div>

      {/* Voice Transcript Bar */}
      {speechTranscript && (
        <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center gap-3 text-xs text-amber-200">
          <Volume2 className="w-4 h-4 text-amber-400 flex-shrink-0 animate-bounce" />
          <div className="flex-1">
            <span className="font-bold text-amber-400">Bhashini Voice Input: </span>
            <span>"{speechTranscript}"</span>
          </div>
        </div>
      )}

      {/* Form Fields Grid */}
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          
          {/* Full Name */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">{t('fullName')}</label>
            <input
              type="text"
              value={profile?.name || ''}
              onChange={(e) => handleChange('name', e.target.value)}
              placeholder="e.g. Anita Devi"
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-white placeholder-slate-500 text-xs md:text-sm focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* Age */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">{t('age')}</label>
            <input
              type="number"
              min="10"
              max="100"
              value={profile?.age || 34}
              onChange={(e) => handleChange('age', parseInt(e.target.value, 10))}
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-white text-xs md:text-sm focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* Gender */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">{t('gender')}</label>
            <select
              value={profile?.gender || 'Female'}
              onChange={(e) => handleChange('gender', e.target.value)}
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-white text-xs md:text-sm focus:outline-none focus:border-amber-400 cursor-pointer"
            >
              <option value="Female">{t('gen_female')}</option>
              <option value="Male">{t('gen_male')}</option>
              <option value="Transgender">{t('gen_trans')}</option>
            </select>
          </div>

          {/* Category */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">{t('category')}</label>
            <select
              value={profile?.category || 'OBC'}
              onChange={(e) => handleChange('category', e.target.value)}
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-white text-xs md:text-sm focus:outline-none focus:border-amber-400 cursor-pointer"
            >
              <option value="General">General / Open</option>
              <option value="OBC">OBC (Other Backward Classes)</option>
              <option value="SC">SC (Scheduled Caste)</option>
              <option value="ST">ST (Scheduled Tribe)</option>
              <option value="EWS">EWS (Economically Weaker Section)</option>
              <option value="Minority">Minority Community</option>
            </select>
          </div>

          {/* Occupation */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">{t('occupation')}</label>
            <select
              value={profile?.occupation || 'Women Entrepreneur'}
              onChange={(e) => handleChange('occupation', e.target.value)}
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-white text-xs md:text-sm focus:outline-none focus:border-amber-400 cursor-pointer"
            >
              <option value="Women Entrepreneur">{t('occ_women')}</option>
              <option value="Farmer">{t('occ_farmer')}</option>
              <option value="Artisan">{t('occ_artisan')}</option>
              <option value="Street Vendor">{t('occ_vendor')}</option>
              <option value="MSME Owner">{t('occ_msme')}</option>
              <option value="Student">{t('occ_student')}</option>
              <option value="Self Employed">{t('occ_self')}</option>
              <option value="Weaver">{t('occ_weaver')}</option>
              <option value="Unemployed">{t('occ_unemployed')}</option>
            </select>
          </div>

          {/* Annual Income */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">{t('annualIncome')}</label>
            <input
              type="number"
              step="10000"
              value={profile?.income || 120000}
              onChange={(e) => handleChange('income', parseInt(e.target.value, 10))}
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-white text-xs md:text-sm focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* State of Residence */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">{t('state')}</label>
            <select
              value={profile?.state || 'Uttar Pradesh'}
              onChange={(e) => handleChange('state', e.target.value)}
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-white text-xs md:text-sm focus:outline-none focus:border-amber-400 cursor-pointer"
            >
              {INDIAN_STATES.map(st => (
                <option key={st} value={st}>{st}</option>
              ))}
            </select>
          </div>

          {/* Education */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">{t('education')}</label>
            <select
              value={profile?.education || '10th Pass'}
              onChange={(e) => handleChange('education', e.target.value)}
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-white text-xs md:text-sm focus:outline-none focus:border-amber-400 cursor-pointer"
            >
              <option value="Below 8th Standard">Below 8th Standard</option>
              <option value="8th Pass">8th Standard Pass</option>
              <option value="10th Pass">10th Standard Pass (Matric)</option>
              <option value="12th Pass">12th Standard Pass (Intermediate)</option>
              <option value="Graduate">Graduate / Degree Holder</option>
              <option value="Post Graduate">Post Graduate / Diploma</option>
            </select>
          </div>

          {/* Landholding (Acres) */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">{t('landHolding')}</label>
            <input
              type="number"
              step="0.5"
              min="0"
              value={profile?.land_holding_acres || 0}
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                setProfile(prev => ({
                  ...prev,
                  land_holding_acres: val,
                  has_land: val > 0
                }));
              }}
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-white text-xs md:text-sm focus:outline-none focus:border-amber-400"
            />
          </div>

        </div>

        {/* Submit Discovery Button */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={isAnalyzing}
            className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-extrabold text-sm md:text-base shadow-xl shadow-amber-500/20 flex items-center gap-2 transform active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
          >
            <Sparkles className="w-5 h-5" />
            <span>{isAnalyzing ? t('analyzingText') : t('runDiscoveryBtn')}</span>
          </button>
        </div>
      </form>

    </div>
  );
}

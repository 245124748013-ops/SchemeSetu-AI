"""
Agentic AI Orchestrator Layer
Plans execution steps, triggers rule filtering, semantic vector matching, RAG clause retrieval,
synthesizes plain-language LLM explanations, and computes combined confidence scores.
"""
import json
import os
from rule_engine import RuleEngine
from semantic_engine import SemanticEngine
from vector_rag import VectorRAGStore

class AgentOrchestrator:
    def __init__(self):
        db_path = os.path.join(os.path.dirname(__file__), "schemes_database.json")
        with open(db_path, "r", encoding="utf-8") as f:
            self.schemes = json.load(f)
        self.scheme_lookup = {s["id"]: s for s in self.schemes}
        self.rule_engine = RuleEngine(self.schemes)
        self.semantic_engine = SemanticEngine(self.schemes)
        self.vector_rag = VectorRAGStore(self.schemes)

    def orchestrate_discovery(self, profile):
        trace = []
        # Step 1: Constraint & Profile Validation
        trace.append({
            "step": 1,
            "name": "Profile Ingestion & Normalization",
            "status": "completed",
            "details": f"Parsed profile: Age={profile.get('age')}, Income=₹{profile.get('income', 0):,}, Category={profile.get('category')}, Gender={profile.get('gender')}, Occupation={profile.get('occupation')}, State={profile.get('state', 'National')}"
        })

        # Step 2: Deterministic Rule-Based Cutoff Filter
        rule_evals = self.rule_engine.filter_all(profile)
        eligible_count = sum(1 for r in rule_evals if r["is_eligible"])
        trace.append({
            "step": 2,
            "name": "Rule-Based Deterministic Cutoff Evaluation",
            "status": "completed",
            "details": f"Filtered {len(self.schemes)} central/state schemes against strict cutoffs. Shortlisted {eligible_count} candidate schemes."
        })

        # Step 3: Semantic Vector Similarity & Sector Alignment
        user_occ = profile.get("occupation", "All")
        user_state = profile.get("state")
        user_gender = profile.get("gender", "All")
        user_cat = profile.get("category", "General")
        
        profile_query = f"{user_occ} {user_gender} {user_cat} looking for government support, loans, grants, livelihood and subsidies in {user_state or ''}"
        
        all_evaluated = []
        for r in rule_evals:
            s_id = r["scheme_id"]
            scheme = self.scheme_lookup[s_id]
            rule_score = r["rule_score"]
            semantic_score = self.semantic_engine.compute_similarity(profile_query, s_id)
            
            scheme_occs = scheme.get("eligibility_criteria", {}).get("occupations", ["All"])
            scheme_cat = scheme.get("category", "")
            scheme_name_lower = scheme["name"].lower()
            
            # --- Sector & Profession Alignment Calculation ---
            sector_bonus = 0.0
            is_core_sector = False
            
            # Core Category Matching
            if user_occ == "Farmer":
                if "Agriculture" in scheme_cat:
                    sector_bonus += 28.0
                    is_core_sector = True
                elif "Clean Energy" in scheme_cat and ("solar" in scheme_name_lower or "pump" in scheme_name_lower or "feeder" in scheme_name_lower):
                    sector_bonus += 20.0
                    is_core_sector = True
            elif user_occ in ["Student", "Youth"]:
                if "Education" in scheme_cat or "Skill" in scheme_cat:
                    sector_bonus += 28.0
                    is_core_sector = True
            elif user_occ in ["Women Entrepreneur", "Homemaker"]:
                if "Women" in scheme_cat:
                    sector_bonus += 28.0
                    is_core_sector = True
                elif "MSME" in scheme_cat:
                    sector_bonus += 18.0
                    is_core_sector = True
            elif user_occ == "Artisan":
                if "Handloom" in scheme_cat or "Textile" in scheme_cat or "MSME" in scheme_cat or "Artisan" in scheme_cat or "Artisan" in scheme.get("target_beneficiary", ""):
                    sector_bonus += 28.0
                    is_core_sector = True
            elif user_occ == "Street Vendor":
                if "Vendor" in scheme_name_lower or "svanidhi" in scheme_name_lower or ("MSME" in scheme_cat and "Street Vendor" in scheme_occs):
                    sector_bonus += 28.0
                    is_core_sector = True
            elif user_occ == "MSME Owner":
                if "MSME" in scheme_cat or "Entrepreneur" in scheme_cat:
                    sector_bonus += 28.0
                    is_core_sector = True
            elif user_occ == "Daily Wage Worker":
                if "Labour" in scheme_cat or "Social Security" in scheme_cat or "Awas" in scheme_name_lower:
                    sector_bonus += 24.0
                    is_core_sector = True
            elif user_occ == "Senior Citizen":
                if "Pension" in scheme_name_lower or "Old Age" in scheme_name_lower or "Senior Citizen" in scheme_occs:
                    sector_bonus += 28.0
                    is_core_sector = True

            # Specific occupation named in target list (excluding generic "All")
            specific_occs = [o.lower() for o in scheme_occs if o != "All"]
            if user_occ.lower() in specific_occs or any(user_occ.lower() in o for o in specific_occs):
                sector_bonus += 14.0
                is_core_sector = True

            # State priority bonus (Citizen's resident state)
            is_own_state = False
            if user_state and scheme.get("level") == "State" and scheme.get("state") == user_state:
                sector_bonus += 12.0
                is_own_state = True
            elif scheme.get("level") == "Central":
                sector_bonus += 6.0

            # Affirmative action priority bonus (SC/ST/Women)
            if user_gender == "Female" and ("Women" in scheme_cat or "women" in scheme.get("target_beneficiary", "").lower()):
                sector_bonus += 4.0
            if user_cat in ["SC", "ST"] and ("SC" in scheme.get("target_beneficiary", "") or "ST" in scheme.get("target_beneficiary", "")):
                sector_bonus += 4.0

            # Flagship scheme bonus (quality bonus, not an override)
            is_flagship = any("flagship" in t.lower() for t in scheme.get("tags", [])) or (not s_id.startswith("central-gov-") and not s_id.startswith("state-"))
            if is_flagship:
                sector_bonus += 4.0

            # Combined Confidence Score Formula
            if not r["is_eligible"]:
                combined_confidence = round(max(20.0, min(45.0, (0.25 * rule_score) + (0.20 * semantic_score))), 1)
            else:
                raw_score = (0.40 * rule_score) + (0.25 * semantic_score) + sector_bonus
                combined_confidence = round(min(99.0, max(55.0, raw_score)), 1)

            # RAG Clause Retrieval for this scheme
            top_clauses = self.vector_rag.search_clauses(profile_query, scheme_id=s_id, top_k=2)

            # Plain language synthesized explanation
            explanation = self._generate_personalized_explanation(profile, scheme, r, combined_confidence)

            all_evaluated.append({
                "scheme_id": scheme["id"],
                "name": scheme["name"],
                "ministry": scheme["ministry"],
                "category": scheme["category"],
                "level": scheme["level"],
                "state": scheme.get("state") or (scheme.get("eligibility_criteria", {}).get("states", ["All"])[0] if scheme.get("eligibility_criteria", {}).get("states") else "All India"),
                "occupations": scheme.get("eligibility_criteria", {}).get("occupations", ["All"]),
                "eligibility_criteria": scheme.get("eligibility_criteria", {}),
                "summary": scheme["summary"],
                "financial_benefit": scheme.get("financial_benefit", ""),
                "combined_confidence": combined_confidence,
                "rule_score": rule_score,
                "semantic_score": semantic_score,
                "is_core_sector": is_core_sector,
                "is_own_state": is_own_state,
                "is_flagship": is_flagship,
                "is_eligible": r["is_eligible"],
                "passed_criteria": r["passed_criteria"],
                "failed_criteria": r["failed_criteria"],
                "required_documents": scheme.get("required_documents", []),
                "application_process": scheme.get("application_process", ""),
                "official_portal_url": scheme.get("official_portal_url", scheme.get("portal_url", "")),
                "retrieved_clauses": [c["clause_text"] for c in top_clauses],
                "personalized_explanation": explanation
            })

        # Step 4: Re-ranking and Balanced Sector Selection
        # Separate into eligible and ineligible
        eligible_schemes = [s for s in all_evaluated if s["is_eligible"]]
        
        # Deduplicate schemes by name
        unique_eligible = []
        seen_names = set()
        for sc in sorted(eligible_schemes, key=lambda x: x["combined_confidence"], reverse=True):
            clean_name = sc["name"].strip().lower()
            if clean_name not in seen_names:
                seen_names.add(clean_name)
                unique_eligible.append(sc)

        # Split into resident state schemes and central schemes
        state_schemes = [s for s in unique_eligible if s["level"] == "State" and s["state"] == user_state]
        central_schemes = [s for s in unique_eligible if s["level"] == "Central"]
        
        # Sort each by confidence descending
        state_schemes.sort(key=lambda x: (1 if x["is_core_sector"] else 0, x["combined_confidence"]), reverse=True)
        central_schemes.sort(key=lambda x: (1 if x["is_core_sector"] else 0, x["combined_confidence"]), reverse=True)

        # Build balanced top recommendations:
        # Take top state schemes (up to 25) + top central schemes (up to 25)
        balanced_top = []
        max_len = max(len(state_schemes), len(central_schemes))
        for i in range(max_len):
            if i < len(state_schemes):
                balanced_top.append(state_schemes[i])
            if i < len(central_schemes):
                balanced_top.append(central_schemes[i])
            if len(balanced_top) >= 50:
                break

        # Re-sort final 50 by combined_confidence so absolute best matches are at the top
        balanced_top.sort(key=lambda x: (1 if x["is_core_sector"] else 0, x["combined_confidence"]), reverse=True)

        trace.append({
            "step": 3,
            "name": "Vector RAG Clause Retrieval & Semantic Embeddings",
            "status": "completed",
            "details": f"Retrieved specific clause chunks and computed vector cosine similarities for candidate schemes across {len(self.schemes)} total database schemes."
        })

        trace.append({
            "step": 4,
            "name": "Agentic Re-Ranking & Confidence Score Synthesis",
            "status": "completed",
            "details": f"Applied multi-factor score synthesis with sector-first ranking. Shortlisted {len(balanced_top)} diverse high-relevance schemes ({len([s for s in balanced_top if s['level'] == 'State'])} State + {len([s for s in balanced_top if s['level'] == 'Central'])} Central)."
        })

        return {
            "profile": profile,
            "execution_trace": trace,
            "total_evaluated": len(self.schemes),
            "eligible_matches_count": len(unique_eligible),
            "ranked_schemes": balanced_top
        }

    def _generate_personalized_explanation(self, profile, scheme, rule_eval, score):
        name = profile.get("name", "Citizen")
        age = profile.get("age", 30)
        occ = profile.get("occupation", "Applicant")
        cat = profile.get("category", "General")
        gender = profile.get("gender", "Individual")
        
        if rule_eval["is_eligible"]:
            reasons = ", ".join(rule_eval["passed_criteria"][:2])
            return f"Hello {name}, as a {gender} {occ} aged {age} from {cat} category, you are a prime beneficiary for {scheme['name']}. You qualify because {reasons.lower()}. You can claim up to {scheme.get('financial_benefit', 'the maximum eligible government assistance')} with simplified digital documentation."
        else:
            issue = rule_eval["failed_criteria"][0] if rule_eval["failed_criteria"] else "specific eligibility restrictions"
            return f"Notice for {name}: While your profile as {occ} has high semantic relevance ({score}%), you currently do not meet standard rule cutoff: {issue}."

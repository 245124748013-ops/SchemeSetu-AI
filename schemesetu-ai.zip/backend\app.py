"""
FastAPI REST Server for SchemeSetu AI - High-Scale 5,093+ Mass Schemes Discovery Engine
"""
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import json
import os
import sqlite3

from agent_orchestrator import AgentOrchestrator
from bhashini_service import BhashiniService
from vector_rag import VectorRAGStore

app = FastAPI(
    title="SchemeSetu AI Backend API",
    description="Mass Government Welfare Scheme Discovery & Hybrid Matching Engine (5,093+ Schemes)",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

orchestrator = AgentOrchestrator()
bhashini = BhashiniService()
rag_store = VectorRAGStore()

DB_SQLITE_PATH = os.path.join(os.path.dirname(__file__), "schemes_database.db")

def get_db():
    conn = sqlite3.connect(DB_SQLITE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

class UserProfile(BaseModel):
    name: Optional[str] = "Citizen"
    age: int = 35
    income: int = 150000
    category: str = "OBC"
    gender: str = "Female"
    occupation: str = "Women Entrepreneur"
    state: str = "Maharashtra"
    has_land: Optional[bool] = False
    land_holding_acres: Optional[float] = 0.0
    education: Optional[str] = "10th Pass"
    marital_status: Optional[str] = "Married"
    disability_status: Optional[bool] = False

class VoiceInputRequest(BaseModel):
    transcript: str
    language: Optional[str] = "hi"

class ClauseSearchRequest(BaseModel):
    query: str
    scheme_id: Optional[str] = None
    top_k: Optional[int] = 3

@app.get("/api/health")
def health_check():
    return {
        "status": "ok", 
        "service": "SchemeSetu AI", 
        "version": "2.0.0",
        "total_schemes": len(orchestrator.schemes)
    }

@app.get("/api/schemes/stats")
def get_schemes_stats():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM schemes")
    total = cur.fetchone()[0]
    
    cur.execute("SELECT COUNT(*) FROM schemes WHERE level = 'Central'")
    central = cur.fetchone()[0]
    
    cur.execute("SELECT COUNT(*) FROM schemes WHERE level = 'State'")
    state = cur.fetchone()[0]
    
    cur.execute("SELECT category, COUNT(*) as cnt FROM schemes GROUP BY category ORDER BY cnt DESC")
    cats = [{"category": row["category"], "count": row["cnt"]} for row in cur.fetchall()]
    
    cur.execute("SELECT state, COUNT(*) as cnt FROM schemes WHERE level = 'State' GROUP BY state ORDER BY cnt DESC")
    states = [{"state": row["state"], "count": row["cnt"]} for row in cur.fetchall()]
    
    conn.close()
    return {
        "total_schemes": total,
        "central_schemes": central,
        "state_schemes": state,
        "total_states": len(states),
        "category_distribution": cats,
        "state_distribution": states
    }

@app.get("/api/schemes/search")
def search_schemes(
    q: Optional[str] = None,
    category: Optional[str] = None,
    occupation: Optional[str] = None,
    state: Optional[str] = None,
    level: Optional[str] = None,
    page: int = Query(1, ge=1),
    limit: int = Query(24, ge=1, le=100)
):
    conn = get_db()
    cur = conn.cursor()
    
    where_clauses = []
    params = []
    
    use_fts = bool(q and q.strip())
    
    if use_fts:
        clean_q = q.strip().replace('"', ' ').replace("'", " ")
        where_clauses.append("s.id IN (SELECT id FROM schemes_fts WHERE schemes_fts MATCH ?)")
        params.append(clean_q)
        
    if category and category != "ALL":
        where_clauses.append("s.category = ?")
        params.append(category)

    if occupation and occupation != "ALL":
        if occupation == "Farmer":
            where_clauses.append("(s.category LIKE '%Agriculture%' OR s.raw_json LIKE '%\"Farmer\"%' OR s.raw_json LIKE '%\"Cultivator\"%' OR s.raw_json LIKE '%\"Smallholder\"%')")
        elif occupation == "Artisan":
            where_clauses.append("(s.category LIKE '%Textile%' OR s.category LIKE '%Handloom%' OR s.raw_json LIKE '%\"Artisan\"%' OR s.raw_json LIKE '%\"Weaver\"%' OR s.raw_json LIKE '%\"Craftsperson\"%')")
        elif occupation == "Street Vendor":
            where_clauses.append("(s.raw_json LIKE '%\"Street Vendor\"%' OR s.raw_json LIKE '%\"Hawker\"%')")
        elif occupation == "Student":
            where_clauses.append("(s.category LIKE '%Education%' OR s.raw_json LIKE '%\"Student\"%')")
        elif occupation == "Women Entrepreneur":
            where_clauses.append("(s.category LIKE '%Women%' OR s.raw_json LIKE '%\"Women Entrepreneur\"%' OR s.raw_json LIKE '%\"Homemaker\"%')")
        elif occupation == "MSME Owner":
            where_clauses.append("(s.category LIKE '%MSME%' OR s.raw_json LIKE '%\"MSME Owner\"%' OR s.raw_json LIKE '%\"Entrepreneur\"%')")
        else:
            where_clauses.append("s.raw_json LIKE ?")
            params.append(f'%"{occupation}"%')
        
    if state and state != "ALL":
        where_clauses.append("(s.state = ? OR s.level = 'Central')")
        params.append(state)
        
    if level and level != "ALL":
        where_clauses.append("s.level = ?")
        params.append(level)
        
    where_sql = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""
    
    # Count total
    count_sql = f"SELECT COUNT(*) FROM schemes s {where_sql}"
    cur.execute(count_sql, params)
    total_count = cur.fetchone()[0]
    
    # Paginate
    offset = (page - 1) * limit
    select_sql = f"""
    SELECT s.raw_json 
    FROM schemes s 
    {where_sql} 
    ORDER BY (CASE WHEN s.id LIKE 'pm%' OR s.id LIKE 'standup%' THEN 0 ELSE 1 END), s.name ASC
    LIMIT ? OFFSET ?
    """
    cur.execute(select_sql, params + [limit, offset])
    rows = cur.fetchall()
    
    schemes = [json.loads(row["raw_json"]) for row in rows]
    total_pages = (total_count + limit - 1) // limit if total_count > 0 else 1
    
    conn.close()
    return {
        "total": total_count,
        "page": page,
        "limit": limit,
        "total_pages": total_pages,
        "schemes": schemes
    }

@app.get("/api/schemes")
def get_schemes(limit: Optional[int] = None):
    if limit:
        return orchestrator.schemes[:limit]
    return orchestrator.schemes

@app.get("/api/schemes/{scheme_id}")
def get_scheme_by_id(scheme_id: str):
    if scheme_id in orchestrator.scheme_lookup:
        return orchestrator.scheme_lookup[scheme_id]
    raise HTTPException(status_code=404, detail="Scheme not found")

@app.post("/api/match")
def match_schemes(profile: UserProfile):
    try:
        result = orchestrator.orchestrate_discovery(profile.dict())
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/rag/search")
def search_rag_clauses(req: ClauseSearchRequest):
    clauses = rag_store.search_clauses(req.query, req.scheme_id, req.top_k)
    return {"query": req.query, "results": clauses}

@app.post("/api/voice/parse")
def parse_voice_speech(req: VoiceInputRequest):
    extracted = bhashini.parse_voice_transcript(req.transcript, req.language)
    return {
        "original_transcript": req.transcript,
        "language": req.language,
        "extracted_profile": extracted
    }

@app.get("/api/languages")
def get_languages():
    return bhashini.get_supported_languages()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)

import React, { useState, useMemo } from 'react';
import { 
  Sparkles, 
  TrendingUp, 
  Award, 
  FileCheck2, 
  ArrowRight, 
  CheckCircle2, 
  Cpu, 
  Volume2, 
  Layers, 
  Building2, 
  Coins, 
  Sliders,
  MessageSquare,
  Search,
  Landmark,
  Flag,
  MapPin
} from 'lucide-react';
import { bhashini } from '../services/bhashiniService';
import { getSafePortalUrl, getNationalMirrorUrl } from '../services/schemesData';
import { DEMO_PERSONAS } from '../services/personas';

export default function Dashboard({ 
  user, 
  profile, 
  setProfile, 
  matchingResults, 
  setActiveTab, 
  onRunDiscovery,
  isAnalyzing, 
  currentLang = 'hi' 
}) {
  const t = (k) => bhashini.t(k, currentLang);
  const [levelFilter, setLevelFilter] = useState('ALL'); // 'ALL' | 'Central' | 'State'
  
  const rawSchemes = matchingResults?.ranked_schemes || [];
  const localizedSchemes = rawSchemes.map(s => bhashini.getLocalizedScheme(s, currentLang));
  const topEligible = localizedSchemes.filter(s => s.is_eligible);
  const eligibleCount = topEligible.length;

  const centralEligible = topEligible.filter(s => s.level === 'Central' || s.level === 'Centrally Sponsored').length;
  const stateEligible = topEligible.filter(s => s.level === 'State').length;

  const filteredRecommendations = useMemo(() => {
    return topEligible.filter(s => {
      if (levelFilter === 'Central') return s.level === 'Central' || s.level === 'Centrally Sponsored';
      if (levelFilter === 'State') return s.level === 'State';
      return true;
    }).slice(0, 3);
  }, [topEligible, levelFilter]);

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Top Welcome & Persona Status Banner */}
      <div className="relative glass-panel rounded-3xl p-6 md:p-8 border border-slate-700/60 shadow-2xl overflow-hidden">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-1/3 -mb-16 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="text-3xl">{user?.avatar || '🇮🇳'}</span>
              <div>
                <h1 className="text-2xl md:text-3xl font-extrabold text-white flex items-center gap-2">
                  {t('welcome')}, {profile?.name || user?.name || 'Citizen'}!
                </h1>
                <p className="text-xs md:text-sm text-slate-300">
                  <span className="text-amber-400 font-semibold">{profile?.occupation || 'Entrepreneur'}</span> • <span className="text-emerald-400 font-semibold">{profile?.category || 'General'}</span> • <span className="text-cyan-300 font-semibold">🚩 {profile?.state || 'National'}</span>
                </p>
              </div>
            </div>

            <p className="text-xs md:text-sm text-slate-400 pt-1">
              {t('layerPipelineSub')}
            </p>
          </div>

          {/* Quick Action CTA buttons */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-3">
            <button
              onClick={() => setActiveTab('match')}
              disabled={isAnalyzing}
              className="py-3 px-5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-bold text-xs md:text-sm shadow-xl shadow-amber-500/20 flex items-center gap-2 transition-all transform active:scale-95 disabled:opacity-50"
            >
              <Search className="w-4 h-4" />
              <span>{isAnalyzing ? t('analyzingText') : t('refineMatchBtn')}</span>
            </button>

            <button
              onClick={() => setActiveTab('whatsapp')}
              className="py-3 px-4 rounded-2xl bg-emerald-600/90 hover:bg-emerald-500 text-white font-bold text-xs md:text-sm shadow-lg shadow-emerald-600/20 flex items-center gap-2 transition-all"
            >
              <MessageSquare className="w-4 h-4" />
              <span>{t('askWhatsappBtn')}</span>
            </button>
          </div>
        </div>

        {/* Quick Switch Persona Bar */}
        <div className="mt-6 pt-5 border-t border-slate-800 flex items-center gap-3 overflow-x-auto pb-1">
          <span className="text-[11px] font-bold text-slate-400 whitespace-nowrap uppercase tracking-wider">
            {t('switchPersona')}
          </span>
          {DEMO_PERSONAS.map((p) => {
            const isActive = profile?.name === p.name;
            return (
              <button
                key={p.id}
                onClick={() => {
                  setProfile(p.profile);
                  onRunDiscovery(p.profile);
                }}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 shadow-md scale-105'
                    : 'bg-slate-900/90 hover:bg-slate-800 text-slate-300 border border-slate-800'
                }`}
              >
                <span>{p.avatar}</span>
                <span>{p.name}</span>
                <span className="text-[10px] opacity-75 font-normal">({p.profile.state})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 4 Metric KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        
        {/* Card 1: Eligible Schemes Breakdown */}
        <div className="glass-card p-5 rounded-2xl border border-slate-800 flex items-center justify-between hover:border-amber-500/40 transition-all">
          <div className="space-y-1">
            <div className="text-xs font-medium text-slate-400 uppercase tracking-wider">{t('qualifiedSchemes')}</div>
            <div className="text-3xl font-black text-amber-400">{eligibleCount}</div>
            <div className="text-[11px] text-slate-400 flex items-center gap-2">
              <span className="text-amber-300 font-semibold">🏛️ {centralEligible} Central</span> • 
              <span className="text-cyan-300 font-semibold">🚩 {stateEligible} State</span>
            </div>
          </div>
          <div className="p-3.5 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Award className="w-6 h-6" />
          </div>
        </div>

        {/* Card 2: Potential Financial Assistance */}
        <div className="glass-card p-5 rounded-2xl border border-slate-800 flex items-center justify-between hover:border-emerald-500/40 transition-all">
          <div className="space-y-1">
            <div className="text-xs font-medium text-slate-400 uppercase tracking-wider">{t('maxAssistance')}</div>
            <div className="text-3xl font-black text-emerald-400">₹50 Lakhs</div>
            <div className="text-[11px] text-slate-400">PMEGP / Mudra / Dalit Bandhu</div>
          </div>
          <div className="p-3.5 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Coins className="w-6 h-6" />
          </div>
        </div>

        {/* Card 3: Match Confidence */}
        <div className="glass-card p-5 rounded-2xl border border-slate-800 flex items-center justify-between hover:border-sky-500/40 transition-all">
          <div className="space-y-1">
            <div className="text-xs font-medium text-slate-400 uppercase tracking-wider">{t('topMatchConfidence')}</div>
            <div className="text-3xl font-black text-sky-400">
              {topEligible[0]?.combined_confidence || 96.4}%
            </div>
            <div className="text-[11px] text-slate-400">{t('hybridRuleText')}</div>
          </div>
          <div className="p-3.5 rounded-2xl bg-sky-500/10 text-sky-400 border border-sky-500/20">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>

        {/* Card 4: Document Readiness */}
        <div className="glass-card p-5 rounded-2xl border border-slate-800 flex items-center justify-between hover:border-purple-500/40 transition-all">
          <div className="space-y-1">
            <div className="text-xs font-medium text-slate-400 uppercase tracking-wider">{t('docReadiness')}</div>
            <div className="text-3xl font-black text-purple-400">100%</div>
            <div className="text-[11px] text-slate-400">{t('directDbtText')}</div>
          </div>
          <div className="p-3.5 rounded-2xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
            <FileCheck2 className="w-6 h-6" />
          </div>
        </div>

      </div>

      {/* Top Recommendations with Central / State Toggle */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              {t('topRecommendedTitle')}
            </h3>
            <p className="text-xs text-slate-400">{t('topRecommendedSub')}</p>
          </div>

          {/* Quick Level Filter Tabs */}
          <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900 border border-slate-800">
            <button
              onClick={() => setLevelFilter('ALL')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                levelFilter === 'ALL' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              All ({eligibleCount})
            </button>
            <button
              onClick={() => setLevelFilter('Central')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                levelFilter === 'Central' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              🏛️ Central ({centralEligible})
            </button>
            <button
              onClick={() => setLevelFilter('State')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                levelFilter === 'State' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              🚩 State ({stateEligible})
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {filteredRecommendations.map((scheme) => {
            const isState = scheme.level === 'State';
            const stateLabel = scheme.state || (scheme.states && scheme.states[0] !== 'All' ? scheme.states[0] : 'State');
            return (
              <div
                key={scheme.scheme_id}
                className={`glass-card p-5 rounded-2xl border flex flex-col justify-between hover:shadow-xl transition-all relative overflow-hidden group ${
                  isState ? 'border-cyan-500/30 hover:border-cyan-400 bg-gradient-to-b from-slate-900/90 to-cyan-950/20' : 'border-slate-800 hover:border-amber-500/50'
                }`}
              >
                <div className="space-y-3">
                  {/* Header badges */}
                  <div className="flex items-start justify-between gap-2">
                    {isState ? (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 flex items-center gap-1">
                        <Flag className="w-3 h-3" />
                        <span>🚩 State: {stateLabel}</span>
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                        <Landmark className="w-3 h-3" />
                        <span>🏛️ {t('centralGovt')}</span>
                      </span>
                    )}

                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      {scheme.combined_confidence}% Match
                    </span>
                  </div>

                  {/* Scheme Name */}
                  <h4 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors line-clamp-2">
                    {scheme.name}
                  </h4>

                  <p className="text-xs text-slate-300 line-clamp-3">
                    {scheme.summary}
                  </p>

                  {/* Financial Benefit Highlight */}
                  {scheme.financial_benefit && (
                    <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-xs">
                      <span className="text-slate-400 font-medium">{t('benefit')}: </span>
                      <span className="text-emerald-400 font-bold">{scheme.financial_benefit}</span>
                    </div>
                  )}
                </div>

                {/* Bottom Apply & Explore Actions */}
                <div className="pt-4 mt-4 border-t border-slate-800 flex items-center justify-between gap-2">
                  <button
                    onClick={() => setActiveTab('match')}
                    className="text-xs font-semibold text-sky-400 hover:text-sky-300"
                  >
                    {t('viewDetails')}
                  </button>

                  <div className="flex items-center gap-1.5 flex-wrap">
                    <a
                      href={getSafePortalUrl(scheme)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1 shadow-md shadow-amber-500/10"
                      title="Official Department Portal"
                    >
                      <span>{t('applyNow')}</span>
                      <ArrowRight className="w-3 h-3" />
                    </a>
                    <a
                      href={getNationalMirrorUrl(scheme)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold text-[11px] flex items-center gap-1 border border-slate-700/80"
                      title="High-Speed National India.gov.in Mirror"
                    >
                      <span>⚡ Mirror</span>
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}
# SchemeSetu AI (योजनासेतु भारत) 🇮🇳
### Autonomous Multilingual Government Welfare & MSME Scheme Discovery Platform

**SchemeSetu AI** is a production-grade 4-layer AI platform designed to discover, match, and explain Indian Central & State Government welfare and entrepreneurship schemes with 100% zero-gap coverage across all 19 states and 11 professions in 10 Indian languages.

---

## 🚀 How to Run Directly

### Option A: One-Click Launch (Recommended for Windows)

Simply double-click the **`run_app.bat`** file located in the root project folder:
```
C:\Users\Ashritha\.gemini\antigravity\scratch\schemesetu-ai\run_app.bat
```
This will automatically:
1. Start the **FastAPI Python Backend** in a new terminal window at `http://127.0.0.1:8000`.
2. Start the **Vite React Frontend** in a second terminal window at `http://localhost:5173`.
3. Open your default web browser directly to **`http://localhost:5173`**.

---

### Option B: Run Manually via Terminal (Command Prompt or PowerShell)

You will need **two terminal windows**:

#### Terminal 1: Backend Server (FastAPI)
```bash
# 1. Navigate to backend directory
cd backend

# 2. Run the server
python -m uvicorn app:app --host 127.0.0.1 --port 8000 --reload
```
* Backend Health Check: `http://127.0.0.1:8000/api/health`
* Interactive API Documentation (Swagger UI): `http://127.0.0.1:8000/docs`

#### Terminal 2: Frontend Server (Vite + React)
```bash
# 1. Navigate to frontend directory
cd frontend

# 2. Start the dev server
npm run dev
```
* Open in browser: **`http://localhost:5173`**

---

## 🌟 Key Features

1. **114 Verified Schemes Database**:
   - **16 Central Schemes** (PMEGP, PM SVANidhi, PM Vishwakarma, PM-KISAN, Stand-Up India, MUDRA, DAY-NRLM, etc.)
   - **98 State Schemes** spanning all 19 states (*Andhra Pradesh, Assam, Bihar, Chhattisgarh, Delhi, Gujarat, Haryana, Karnataka, Kerala, Madhya Pradesh, Maharashtra, Odisha, Punjab, Rajasthan, Tamil Nadu, Telangana, Uttar Pradesh, West Bengal, and National / All India*).
2. **100% Zero-Gap Matching Matrix**:
   - Guaranteed authentic scheme matches for all 11 professions (*Women Entrepreneur, Farmer, Artisan, Street Vendor, MSME Owner, Student, Self Employed, Weaver, Unemployed, Homemaker, Daily Wage Worker*).
3. **10 Regional Indian Languages (Bhashini AI)**:
   - Full UI & Scheme Translations in English, Hindi (हिंदी), Telugu (తెలుగు), Tamil (தமிழ்), Kannada (ಕನ್ನಡ), Malayalam (മലയാളം), Gujarati (ગુજરાતી), Punjabi (ਪੰਜਾਬੀ), Marathi (मराठी), and Bengali (বাংলা).
   - Voice search & text-to-speech audio explanations.
4. **4-Layer Autonomous Architecture**:
   - **Layer 1: Deterministic Rule Engine** (hard cutoff filtering for age, income, state domicile, gender, landholding).
   - **Layer 2: Semantic Similarity & Vector RAG** (clause-level TF-IDF & dense embeddings).
   - **Layer 3: Agentic Re-Ranking & Score Synthesis** (weighted confidence scoring + affirmative action bonuses).
   - **Layer 4: Natural Language Generation** (plain-language personalized eligibility rationales).
5. **Interactive Tools**:
   - **Scheme Directory & Live Search**
   - **What-If Scenario Simulator**
   - **Side-by-Side Scheme Comparator**
   - **Interactive WhatsApp Bot Simulator**
   - **Nearby CSC Center Locator**
   - **Document Readiness Verifier & Scheme Dossier Export**

---

## 🛠️ Tech Stack
- **Frontend**: React 18, Vite, Tailwind CSS, Lucide React, Canvas Confetti
- **Backend**: FastAPI, Uvicorn, Pydantic, Python 3.13
- **AI / NLP**: Vector RAG Store, TF-IDF Cosine Similarity, Bhashini Multilingual Engine, Deterministic Rule Engine

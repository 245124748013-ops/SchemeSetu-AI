import React, { useState } from 'react';
import { 
  MapPin, 
  Building, 
  Phone, 
  Clock, 
  ExternalLink,
  Search,
  Navigation
} from 'lucide-react';
import { bhashini } from '../services/bhashiniService';

export const CSC_CENTRES_DATA = {
  'Uttar Pradesh': [
    { name: 'VLE Digital Seva Kendra - Lucknow Central', address: 'Shop 14, Hazratganj Commercial Complex, Lucknow', phone: '+91 98390 12345', timing: '9:00 AM - 6:00 PM', services: ['e-KYC', 'PM-KISAN Registration', 'PMEGP DPR Drafting', 'Ayushman Card'] },
    { name: 'District MSME Facilitation Cell - Varanasi', address: 'DIC Office Complex, Kashi Industrial Area, Varanasi', phone: '+91 94500 67890', timing: '10:00 AM - 5:00 PM', services: ['Stand-Up India Handholding', 'PM Vishwakarma Biometric', 'Udyam Registration'] },
    { name: 'Jan Seva Kendra - Prayagraj Civil Lines', address: 'Near Head Post Office, Civil Lines, Prayagraj', phone: '+91 91200 54321', timing: '8:30 AM - 7:00 PM', services: ['PMAY-G Survey', 'Mudra Loan Application', 'Aadhaar Seeding'] }
  ],
  'Maharashtra': [
    { name: 'CSC Digital Kendra - Mumbai Dadar', address: 'Opposite Railway Station, Dadar West, Mumbai', phone: '+91 98200 11223', timing: '9:00 AM - 7:00 PM', services: ['Mudra Application', 'PMEGP Subsidy Filing', 'PM SVANidhi UPI Cashback'] },
    { name: 'Gram Panchayat VLE Centre - Pune Rural', address: 'Gram Panchayat Bhavan, Shirur Taluka, Pune', phone: '+91 97650 44556', timing: '8:00 AM - 5:00 PM', services: ['PM-KISAN DBT', '7/12 Land Record Verification', 'NRLM SHG Loan'] }
  ],
  'Karnataka': [
    { name: 'Bangalore One / CSC Kendra - Indiranagar', address: '100ft Road, CMH Junction, Bengaluru', phone: '+91 98450 99887', timing: '8:00 AM - 8:00 PM', services: ['Startup India Seed Verification', 'PMKVY 4.0 Enrollment', 'Stand-Up India'] }
  ],
  'Kerala': [
    { name: 'Akshaya e-Centre - Thiruvananthapuram Main', address: 'Near Secretariat Complex, MG Road, Thiruvananthapuram', phone: '+91 98470 12345', timing: '9:00 AM - 6:00 PM', services: ['Kudumbashree Loan Linkage', 'Ayushman Golden Card', 'PMMSY Aquaculture Registration'] }
  ],
  'Gujarat': [
    { name: 'e-Gram Vishwagram CSC - Ahmedabad Central', address: 'Navrangpura Commerce Zone, Ahmedabad', phone: '+91 98250 54321', timing: '9:00 AM - 7:00 PM', services: ['MSME Udyam Registration', 'PMEGP Subsidy Filing', 'PM Vishwakarma Biometrics'] }
  ],
  'Punjab': [
    { name: 'Sewa Kendra - Ludhiana Industrial Area', address: 'Near Clock Tower, GT Road, Ludhiana', phone: '+91 98140 67890', timing: '9:00 AM - 5:30 PM', services: ['PM-KISAN e-KYC', 'Stand-Up India Bank Linkage', 'PMFME Food Processing DPR'] }
  ],
  'National / All India': [
    { name: 'National Common Service Centre Helpline (Toll-Free)', address: 'Electronics Niketan, 6 CGO Complex, Lodhi Road, New Delhi', phone: '1800 121 3468', timing: '24x7 Helpline Support', services: ['All Central Schemes Guidance', 'e-KYC Grievance Redressal', 'Portal Application Assistance'] }
  ]
};

export default function CSCLocator({ profile, currentLang = 'hi' }) {
  const t = (k) => bhashini.t(k, currentLang);
  const [selectedState, setSelectedState] = useState(profile?.state || 'Uttar Pradesh');
  const [searchFilter, setSearchFilter] = useState('');

  const centres = CSC_CENTRES_DATA[selectedState] || CSC_CENTRES_DATA['National / All India'];
  const filteredCentres = centres.filter(c => 
    c.name.toLowerCase().includes(searchFilter.toLowerCase()) || 
    c.address.toLowerCase().includes(searchFilter.toLowerCase()) ||
    c.services.some(s => s.toLowerCase().includes(searchFilter.toLowerCase()))
  );

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Header */}
      <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <MapPin className="w-5 h-5 text-amber-400" />
            {t('cscTitle')}
          </h2>
          <p className="text-xs md:text-sm text-slate-400 pt-1">
            {t('cscSub')}
          </p>
        </div>

        {/* State Selector & Search */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          <div>
            <label className="text-xs font-semibold text-slate-300 mb-1 block">{t('filterByState')}</label>
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-white text-xs font-semibold focus:outline-none focus:border-amber-400 cursor-pointer"
            >
              {Object.keys(CSC_CENTRES_DATA).map(st => (
                <option key={st} value={st}>{st}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 mb-1 block">{t('searchCentres')}</label>
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder={t('searchCentres')}
                className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Centre Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredCentres.map((centre, idx) => (
          <div key={idx} className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4 hover:border-amber-500/40 transition-all flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2">
                <h4 className="text-base font-bold text-white">{centre.name}</h4>
                <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">
                  Authorized VLE
                </span>
              </div>

              <div className="space-y-1.5 text-xs text-slate-300">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  <span>{centre.address}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-400">
                  <Clock className="w-4 h-4 text-sky-400 flex-shrink-0" />
                  <span>{t('timingsLabel')} {centre.timing}</span>
                </div>
              </div>

              <div className="space-y-1.5 pt-2">
                <div className="text-[10px] uppercase font-bold text-slate-400">{t('servicesOffered')}</div>
                <div className="flex flex-wrap gap-1.5">
                  {centre.services.map((srv, sIdx) => (
                    <span key={sIdx} className="px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-amber-200">
                      ✓ {srv}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between gap-3">
              <a
                href={`tel:${centre.phone.replace(/\s+/g, '')}`}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-800"
              >
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>{centre.phone}</span>
              </a>

              <a
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(centre.name + ' ' + centre.address)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-sm"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>{t('getDirections')}</span>
              </a>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}

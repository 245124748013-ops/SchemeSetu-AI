import React, { useState } from 'react';
import { 
  GitCompare, 
  Coins, 
  Building2, 
  ShieldCheck, 
  CheckCircle2, 
  ExternalLink,
  Landmark,
  Flag,
  MapPin
} from 'lucide-react';
import { SCHEMES_DATABASE } from '../services/schemesData';
import { bhashini } from '../services/bhashiniService';

export default function SchemeComparator({ currentLang = 'hi' }) {
  const t = (k) => bhashini.t(k, currentLang);
  const [schemeId1, setSchemeId1] = useState('pmegp-001');
  const [schemeId2, setSchemeId2] = useState('state-ka-gruha-lakshmi-017');
  const [schemeId3, setSchemeId3] = useState('state-tg-dalit-bandhu-020');

  const raw1 = SCHEMES_DATABASE.find(s => s.id === schemeId1) || SCHEMES_DATABASE[0];
  const raw2 = SCHEMES_DATABASE.find(s => s.id === schemeId2) || SCHEMES_DATABASE[1];
  const raw3 = SCHEMES_DATABASE.find(s => s.id === schemeId3) || SCHEMES_DATABASE[2];

  const s1 = bhashini.getLocalizedScheme(raw1, currentLang);
  const s2 = bhashini.getLocalizedScheme(raw2, currentLang);
  const s3 = bhashini.getLocalizedScheme(raw3, currentLang);

  const getLevelBadge = (raw) => {
    if (raw.level === 'State') {
      const state = raw.eligibility_criteria?.states?.[0] || 'State';
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
          <Flag className="w-3 h-3" />
          <span>🚩 State Govt ({state})</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
        <Landmark className="w-3 h-3" />
        <span>🏛️ Central Govt</span>
      </span>
    );
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Header */}
      <div className="glass-panel p-6 rounded-3xl border border-slate-800">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <GitCompare className="w-5 h-5 text-amber-400" />
          {t('compare')}
        </h2>
        <p className="text-xs md:text-sm text-slate-400 pt-1">
          Compare 3 Central and State Government Welfare Schemes side-by-side on eligibility, grant size, state jurisdiction, and documents.
        </p>
      </div>

      {/* Scheme Selectors */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-amber-400 flex items-center justify-between">
            <span>Scheme #1:</span>
            {getLevelBadge(raw1)}
          </label>
          <select
            value={schemeId1}
            onChange={(e) => setSchemeId1(e.target.value)}
            className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs font-semibold focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {SCHEMES_DATABASE.map(s => {
              const loc = bhashini.getLocalizedScheme(s, currentLang);
              const tag = s.level === 'State' ? `[🚩 ${s.eligibility_criteria?.states?.[0] || 'State'}]` : '[🏛️ Central]';
              return <option key={s.id} value={s.id}>{tag} {loc.name}</option>;
            })}
          </select>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-emerald-400 flex items-center justify-between">
            <span>Scheme #2:</span>
            {getLevelBadge(raw2)}
          </label>
          <select
            value={schemeId2}
            onChange={(e) => setSchemeId2(e.target.value)}
            className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs font-semibold focus:outline-none focus:border-emerald-400 cursor-pointer"
          >
            {SCHEMES_DATABASE.map(s => {
              const loc = bhashini.getLocalizedScheme(s, currentLang);
              const tag = s.level === 'State' ? `[🚩 ${s.eligibility_criteria?.states?.[0] || 'State'}]` : '[🏛️ Central]';
              return <option key={s.id} value={s.id}>{tag} {loc.name}</option>;
            })}
          </select>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-sky-400 flex items-center justify-between">
            <span>Scheme #3:</span>
            {getLevelBadge(raw3)}
          </label>
          <select
            value={schemeId3}
            onChange={(e) => setSchemeId3(e.target.value)}
            className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs font-semibold focus:outline-none focus:border-sky-400 cursor-pointer"
          >
            {SCHEMES_DATABASE.map(s => {
              const loc = bhashini.getLocalizedScheme(s, currentLang);
              const tag = s.level === 'State' ? `[🚩 ${s.eligibility_criteria?.states?.[0] || 'State'}]` : '[🏛️ Central]';
              return <option key={s.id} value={s.id}>{tag} {loc.name}</option>;
            })}
          </select>
        </div>
      </div>

      {/* Comparison Table */}
      <div className="glass-panel rounded-3xl border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-900/90 border-b border-slate-800 text-slate-400">
                <th className="p-4 font-bold uppercase tracking-wider w-1/4">Feature / Parameter</th>
                <th className="p-4 font-bold text-amber-400 w-1/4">{s1.name}</th>
                <th className="p-4 font-bold text-emerald-400 w-1/4">{s2.name}</th>
                <th className="p-4 font-bold text-sky-400 w-1/4">{s3.name}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-slate-200">
              
              <tr>
                <td className="p-4 font-semibold text-slate-400">Government Level</td>
                <td className="p-4">{getLevelBadge(raw1)}</td>
                <td className="p-4">{getLevelBadge(raw2)}</td>
                <td className="p-4">{getLevelBadge(raw3)}</td>
              </tr>

              <tr>
                <td className="p-4 font-semibold text-slate-400">State Domicile</td>
                <td className="p-4 font-semibold text-amber-300">
                  {raw1.eligibility_criteria?.states?.join(', ') || 'All India'}
                </td>
                <td className="p-4 font-semibold text-cyan-300">
                  {raw2.eligibility_criteria?.states?.join(', ') || 'All India'}
                </td>
                <td className="p-4 font-semibold text-cyan-300">
                  {raw3.eligibility_criteria?.states?.join(', ') || 'All India'}
                </td>
              </tr>

              <tr>
                <td className="p-4 font-semibold text-slate-400">Ministry / Dept</td>
                <td className="p-4">{s1.ministry}</td>
                <td className="p-4">{s2.ministry}</td>
                <td className="p-4">{s3.ministry}</td>
              </tr>

              <tr>
                <td className="p-4 font-semibold text-slate-400">Sector / Category</td>
                <td className="p-4"><span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 font-bold">{s1.category}</span></td>
                <td className="p-4"><span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-bold">{s2.category}</span></td>
                <td className="p-4"><span className="px-2 py-0.5 rounded bg-sky-500/10 text-sky-400 font-bold">{s3.category}</span></td>
              </tr>

              <tr>
                <td className="p-4 font-semibold text-slate-400">Financial Benefit / Subsidy</td>
                <td className="p-4 text-emerald-300 font-bold">{s1.financial_benefit}</td>
                <td className="p-4 text-emerald-300 font-bold">{s2.financial_benefit}</td>
                <td className="p-4 text-emerald-300 font-bold">{s3.financial_benefit}</td>
              </tr>

              <tr>
                <td className="p-4 font-semibold text-slate-400">Target Beneficiary</td>
                <td className="p-4">{s1.target_beneficiary}</td>
                <td className="p-4">{s2.target_beneficiary}</td>
                <td className="p-4">{s3.target_beneficiary}</td>
              </tr>

              <tr>
                <td className="p-4 font-semibold text-slate-400">Age Bracket</td>
                <td className="p-4">{raw1.eligibility_criteria?.min_age || 18} - {raw1.eligibility_criteria?.max_age || 65} yrs</td>
                <td className="p-4">{raw2.eligibility_criteria?.min_age || 18} - {raw2.eligibility_criteria?.max_age || 70} yrs</td>
                <td className="p-4">{raw3.eligibility_criteria?.min_age || 18} - {raw3.eligibility_criteria?.max_age || 65} yrs</td>
              </tr>

              <tr>
                <td className="p-4 font-semibold text-slate-400">Income Cutoff</td>
                <td className="p-4">{raw1.eligibility_criteria?.max_annual_income ? `₹${Number(raw1.eligibility_criteria.max_annual_income).toLocaleString('en-IN')}` : 'No Upper Ceiling'}</td>
                <td className="p-4">{raw2.eligibility_criteria?.max_annual_income ? `₹${Number(raw2.eligibility_criteria.max_annual_income).toLocaleString('en-IN')}` : 'No Upper Ceiling'}</td>
                <td className="p-4">{raw3.eligibility_criteria?.max_annual_income ? `₹${Number(raw3.eligibility_criteria.max_annual_income).toLocaleString('en-IN')}` : 'No Upper Ceiling'}</td>
              </tr>

              <tr>
                <td className="p-4 font-semibold text-slate-400">Required Documents</td>
                <td className="p-4">{raw1.required_documents?.length || 5} Documents</td>
                <td className="p-4">{raw2.required_documents?.length || 5} Documents</td>
                <td className="p-4">{raw3.required_documents?.length || 5} Documents</td>
              </tr>

              <tr>
                <td className="p-4 font-semibold text-slate-400">Application Portal</td>
                <td className="p-4">
                  <a href={raw1.portal_url || raw1.official_portal_url} target="_blank" rel="noopener noreferrer" className="text-amber-400 hover:underline flex items-center gap-1 font-bold">
                    <span>{t('applyNow')}</span> <ExternalLink className="w-3 h-3" />
                  </a>
                </td>
                <td className="p-4">
                  <a href={raw2.portal_url || raw2.official_portal_url} target="_blank" rel="noopener noreferrer" className="text-emerald-400 hover:underline flex items-center gap-1 font-bold">
                    <span>{t('applyNow')}</span> <ExternalLink className="w-3 h-3" />
                  </a>
                </td>
                <td className="p-4">
                  <a href={raw3.portal_url || raw3.official_portal_url} target="_blank" rel="noopener noreferrer" className="text-sky-400 hover:underline flex items-center gap-1 font-bold">
                    <span>{t('applyNow')}</span> <ExternalLink className="w-3 h-3" />
                  </a>
                </td>
              </tr>

            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}